# wsgi.py
# Ajuste o import para seu módulo principal:
# Se seu app Flask está em app.py com variável "app", use "from app import app as application"
# Se está em application.py com variável "application" ou "app", ajuste conforme abaixo.

try:
    from app import app as application      # app.py -> Flask app = app
except Exception:
    try:
        from application import app as application  # application.py -> app
    except Exception:
        from application import application as application  # application.py -> application
