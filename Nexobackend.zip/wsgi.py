# wsgi.py
import os

application = None

# Tentativas diretas de importar a app
for mod, attr in [
    ("app", "app"),
    ("application", "app"),
    ("application", "application"),
    ("main", "app"),
]:
    try:
        m = __import__(mod, fromlist=[attr])
        application = getattr(m, attr)
        break
    except Exception:
        pass

# Tentativa com app factory: create_app()
if application is None:
    for mod in ("app", "application", "main"):
        try:
            m = __import__(mod, fromlist=["create_app"])
            if hasattr(m, "create_app"):
                application = m.create_app()
                break
        except Exception:
            pass

if application is None:
    raise RuntimeError(
        "Não foi possível localizar a aplicação Flask. "
        "Verifique nomes de módulos/variáveis ou forneça create_app()."
    )
